package com.example.demo.model;

public class reviewsShow {
    private customer cust;
    private reviews review;
    

    /**
     * @return customer return the cust
     */
    public customer getCust() {
        return cust;
    }

    /**
     * @param cust the cust to set
     */
    public void setCust(customer cust) {
        this.cust = cust;
    }

    /**
     * @return reviews return the review
     */
    public reviews getReview() {
        return review;
    }

    /**
     * @param review the review to set
     */
    public void setReview(reviews review) {
        this.review = review;
    }

}