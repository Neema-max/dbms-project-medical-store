package com.example.demo.controller.customer;

import org.springframework.stereotype.Controller;

@Controller
public class wishlistCustomerController {
    
}