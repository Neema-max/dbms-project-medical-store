package com.example.demo.controller.customer;

import org.springframework.stereotype.Controller;

@Controller
public class checkOutCustomer {
   // @GetMapping("/checkout")
   // public String checkout(HttpSession session , Model model){
   //     if(auth.isCustomer(session) && auth.isLoggedIn(session)){
   //         List<itemsShow> cart = ccs.getCutomerCart(session);
   //         model.addAttribute("cart", cart);
   //         return "auth/customer/checkout";
   //     }
   //     return "redirect : /";
   // }
}