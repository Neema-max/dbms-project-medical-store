package com.example.demo.service.customer;


import org.jvnet.hk2.annotations.Service;
import org.springframework.stereotype.Component;
@Component
@Service
public class customerProfileServ {
    
}